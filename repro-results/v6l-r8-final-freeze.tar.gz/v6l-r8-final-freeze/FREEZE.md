# CREMA/CQPL v6L-r8 frozen baseline

Status:

- discovered Cargo targets: 110
- active targets: 109
- explicitly skipped: 1
- modeled-complete schema-v2 targets: 109
- fail-closed: 0
- hard failures: 0

CQPL schema-v2 queries:

- Leak
- Double-Free
- Use-After-Free RW
- AllocatorMismatch-UB

The frozen semantic oracle is:

    EXPECTED_OUTCOMES_V6L.json

The oracle was generated only after discovery, debugging, corpus adjudication,
and the independent user-facing CQPL run_all experiment.

It must not be modified during confirmation.

Known precision limitations are recorded in:

    KNOWN_LIMITATIONS.md
