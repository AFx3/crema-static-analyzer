# CREMA/CQPL v6L-r8 — Known limitations

## AllocatorMismatch-UB

`allocation_contracts_v1` models allocator compatibility at allocator-family
level.

Known precision limitation:

- C malloc/calloc allocation contracts are `c_malloc`.
- Rust Global allocations are `rust_global`.
- Explicit C free is `c_malloc`.
- Explicit Rust raw deallocation is `rust_global`.
- Generic MIR `Drop` remains `unknown` unless the deallocator family is
  structurally established.

Therefore ordinary Rust owning objects may yield:

    allocator_mismatch = unk

when the allocation family is known but the generic MIR Drop family remains
unknown.

This is a conservative precision limitation. It is not a no-refutation
violation and is intentionally deferred to a future allocator-contract
precision feature gate.

## Allocation identity

Schema-v2 AbstractAllocId and allocation-event labels are MAY abstractions.
Positive MAY witnesses therefore normally evaluate to `unk`, not `tt`.

A future feature gate may add MUST allocation/lifecycle information.

## Memory-leak precision

The v6L analysis is MAY-oriented. A future MUST-analysis feature gate is
reserved for reducing false positives / unknown results for memory-leak
properties.

## Corpus scope

110 Cargo manifests are discovered.

109 are active.

The sole excluded target is:

    no_errors_projects/openapi-client-gen
